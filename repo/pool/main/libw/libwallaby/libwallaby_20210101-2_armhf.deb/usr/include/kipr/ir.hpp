/*
 * ir.hpp
 *
 *  Created on: Nov 13, 2015
 *      Author: Joshua Southerland
 */

#ifndef INCLUDE_WALLABY_IR_HPP_
#define INCLUDE_WALLABY_IR_HPP_


#include "export.h"

class EXPORT_SYM Ir
{
public:
	static void read();
	static void write();
};



#endif /* INCLUDE_WALLABY_IR_HPP_ */
